#requires -Version 7.0
#requires -PSEdition Core
using namespace System.Management.Automation;

Set-StrictMode -Version 6

### HELPERS. Do not Export ##############
function NewError {
    param (
        [string] $Message,
        [string] $Code,
        [ErrorCategory] $Category = [ErrorCategory]::InvalidOperation
    )

    $Exception = [Exception]::new($Message)
    return [ErrorRecord]::new($Exception, $Code, $Category, $null)

}

# this is a helper function that is used to redirect native command stderr into
# stdout while suppressing PS Error Handling options of the outer scope.
# Otherwise if the *native command* is run with redirection and -ErrorAction
# is provided the results get skewed->SilentlyContinue causes errors to not be
# detectabled, and Stop+Redirection throws an error anyways! This wrapper
# causes the errors to flow through without terminating the pipeline. We then
# inspect the results and appropriately react
function WithContinue {

    param(
        [ScriptBlock]$Script
    )

    $ScriptResult = & {
        $ErrorActionPreference = 'Continue'
        & $Script 2>&1
    }

    if ($ScriptResult -is [ErrorRecord]) {
        $ScriptResult
    }
    elseif (!$? -or $LASTEXITCODE) {
        NewError -Message "Operation Failed with Exit Code $LASTEXITCODE" -Code "OperationFailed"
    }
    elseif (!$ScriptResult) {
        NewError -Message "Operation Returned No Data" -Code 'NoData' -Category [ErrorCategory]::InvalidData
    }
    else {
        $ScriptResult
    }
}
### END HELPERS. Do not Export ##############


function Get-ClampedInteger {
    [CmdletBinding(DefaultParameterSetName='Int')]
    param (

        [Parameter(Mandatory, ParameterSetName='Int', Position = 0)]
        [int] $Value,

        [Parameter(Mandatory, ParameterSetName='String', Position = 0)]
        [string] $ValueAsString,

        [Parameter(Mandatory, ParameterSetName='String', Position = 1)]
        [int] $Default,

        [Parameter(Mandatory, ParameterSetName='Int', Position = 1)]
        [Parameter(Mandatory, ParameterSetName='String', Position = 2)]
        [int] $Min,

        [Parameter(Mandatory, ParameterSetName='Int', Position = 2)]
        [Parameter(Mandatory, ParameterSetName='String', Position = 3)]
        [int] $Max
    )

    [int]$Result = $null

    if ($PSCmdlet.ParameterSetName -ieq 'int') {
        $Result = $Value
    }
    elseif (![int]::TryParse("$ValueAsString", [ref] $Result)) {
        $Result = $Default
    }

    return [Math]::Clamp($Result, $Min, $Max)

}

function Write-PipelineVariable {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Name,

        [Parameter(Mandatory=$false)]
        [string] $Value = $null,

        [Parameter(Mandatory=$false)]
        [switch] $Secret,

        [Parameter(Mandatory=$false)]
        [switch] $Silent
    )

    if ($Secret) {
        Write-Host "##vso[task.setvariable variable=$Name;isSecret=true]$Value"
    }
    else {
        Write-Host "##vso[task.setvariable variable=$Name;]$Value"
    }

    if (!$Silent) {
        Write-Host "$($Name): $Value"
    }
}

function Throw-WithFailureMessage {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Message,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $VariableName
    )

    Write-Host $Message
    Write-PipelineVariable -Name $VariableName -Value $Message -Silent
    throw $Message
}

function Get-CanaryStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Namespace,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Canary
    )

    $Spec = WithContinue { kubectl get canary $Canary -n $Namespace -o jsonpath='{.status.phase}' }

    if ($Spec -is [System.Management.Automation.ErrorRecord]) {
        Write-Verbose "Canary Status Check Failed $Spec"
        $PSCmdlet.WriteError($Spec)
    }
    else {
        Write-Verbose "Canary Status: $Spec"
        Write-Output $Spec
    }
}

function Get-CanarySpec {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Namespace,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Canary
    )

    $Spec = WithContinue { kubectl get canary $Canary -n $Namespace -o jsonpath='{.status.lastAppliedSpec}' }

    if ($Spec -is [ErrorRecord]) {
        Write-Verbose "Canary Specification Check Failed $Spec"
        $PSCmdlet.WriteError($Spec)
    }
    else {
        Write-Verbose "Canary Spec: $Spec"
        Write-Output $Spec
    }

}

function Get-DeploymentHash {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Namespace,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Deployment
    )

    $Info = WithContinue { kubectl get deployment -n $Namespace $Deployment -o json }

    if ($Info -is [ErrorRecord]) {
        Write-Verbose "Deployment Specification Check Failed $Info"
        $PSCmdlet.WriteError($Info)
    }
    else {

        $Info = $Info | ConvertFrom-Json -ea Stop

        $bytes = [System.Text.Encoding]::UTF8.GetBytes(($Info.Spec | ConvertTo-Json -Depth 100))
        $hash = Get-FileHash -InputStream ([System.IO.MemoryStream]::new($bytes)) -Algorithm SHA256

        Write-Verbose "Deployment Hash $($hash.Hash)"
        Write-Output $hash.Hash
    }
}

function Wait-ForDeployment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Namespace,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Deployment,

        [Parameter(Mandatory)]
        [ValidateRange([ValidateRangeKind]::NonNegative)]
        [int] $TimeSecs

    )

    Write-Host "Waiting for Deployment Availability (Timeout after $($TimeSecs)s)"

    $result = WithContinue { kubectl wait --for=condition=Available -n $Namespace "deployment/$Deployment" --timeout "$($TimeSecs)s" }

    if ($result -is [ErrorRecord])  {
        Write-Verbose "Deployment Availability Check Failed $result"
        $PSCmdlet.WriteError($result)
    }
    else {
        Write-Verbose "Deployment Availability Check completed successfully"
        Get-DeploymentHash -Namespace $Namespace -Deployment $Deployment
    }

}

function Get-DeploymentUpdateTime {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Namespace,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Deployment
    )

    $Result = WithContinue { kubectl get deployment -n $Namespace $Deployment -o jsonpath="{.status.conditions[?(@.type=='Available')].lastUpdateTime}" }

    if ($Result -is [ErrorRecord]) {
        Write-Verbose "Failed to retrieve Last Update Time for $Deployment $Result"
        $PSCmdlet.WriteError($Result)
    }
    else {
        Write-Verbose "Deployment Last Update Time: $Result"
        Write-Output $Result
    }
}

function Patch-Deployment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Namespace,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Deployment,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $PatchYaml
    )

    $Result = WithContinue { kubectl patch deployment -n $Namespace $Deployment --patch $PatchYaml }

    if ($Result -is [ErrorRecord])  {
        Write-Verbose "Failed to patch deployment $Deployment $Result"
        $PSCmdlet.WriteError($Result)
    }
    elseif ($Result -like '*(no change)*') {
        Write-Verbose "Failed to patch deployment $Deployment. kubectl reported no change"
        $Record = NewError -Message "Failed to patch deployment $Deployment. No change Reported" -Code "OperationFailed"
        $PSCmdlet.WriteError($Record)
    }
    else {
        Write-Verbose "Patch of deployment successful $Result"
        Write-Output $Result
    }

}

Export-ModuleMember Get-CanarySpec
Export-ModuleMember Get-CanaryStatus
Export-ModuleMember Get-ClampedInteger
Export-ModuleMember Get-DeploymentHash
Export-ModuleMember Get-DeploymentUpdateTime
Export-ModuleMember Patch-Deployment
Export-ModuleMember Throw-WithFailureMessage
Export-ModuleMember Wait-ForDeployment
Export-ModuleMember Write-PipelineVariable