#!/bin/bash

# if updated for /bin/sh, need to
#    fix Arrays, ie =>  x=(1,2) to x[1]=1;x[2]=2
#    change redirection into if/fi+IFS

die() { ec=1; if [ "$#" -gt 1 ] && [ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null; then ec="$1"; shift 1; fi; echo "Error: $*" >&2; exit $ec; }
color() { echo -e "\e[$1m$2\e[0m"; }

USAGE=$(cat<<-EOH

usage:
  $0 --context=<CONTEXT> [--kubeconfig=CONFIG]  [--set-vault-perms --vault=<VAULT> --cluster=<CLUSTER>] [--uninstall=<Namespace> [-U]]
  $0 --help

options:
  -x, --context=          required  Kubectl Context
  -k, --kubeconfig=                 Kubectl Configuration file
  -u, --uninstall=                  Uninstall AKV2k8s from this Namespace
      -U                            - When uninstalling, delete Namespace

  -p,--set-vault-perms              Add Vault Certificate Access Policy for Cluster Service Principal
     -v, --vault=        required   - Azure Key Vault where policy will be added
     -c, --cluster=      required   - Name of the AKS Cluster using target Service Principal

  -h,--help                         Prints this message
EOH
)

create_devops_namespace(){

  local KUBEARGS=(--context="$KCONTEXT")
  if [ -n "$KCONFIG" ]; then
    KUBEARGS+=(--kubeconfig="$KCONFIG")
  fi

  color 42 "devops Namespace"

  command kubectl get namespace devops "${KUBEARGS[@]}" >/dev/null 2>&1
  if [ "$?" -ne 0 ]; then
    kubectl create ns devops "${KUBEARGS[@]}"
    if [ "$?" -ne 0 ]; then
      die 3 "Failed to create devops namespace. Aborting..."
    fi
    color 32 "Namespace devops created"
  else
    color 33 "Namespace devops already exits"
  fi

  # ensure labeled
  kubectl label ns devops istio-injection=enabled "${KUBEARGS[@]}" --overwrite

}

uninstall_akv2k8s() {

  color 42 "Uninstalling AKV2K8S from namespace: $1"

  local HELMARGS=(--kube-context="$KCONTEXT")
  local KUBEARGS=(--context="$KCONTEXT")
  if [ -n "$KCONFIG" ]; then
    HELMARGS+=(--kubeconfig="$KCONFIG")
	KUBEARGS+=(--kubeconfig="$KCONFIG")
  fi

  helm delete akv2k8s --namespace "$1" "${HELMARGS[@]}"

  if [ "$2" == "1" ]; then
    color 42 "Deleting namespace $1"
	kubectl delete --ignore-not-found=true ns "$1" "${KUBEARGS[@]}"
  fi

}

install_akv2k8s(){

  color 42 "helm repo updates"
  helm repo add spv-charts https://charts.spvapi.no
  helm repo update

  color 42 "akv2k8s installation"

  local HELMARGS=(--kube-context="$KCONTEXT")
  local KUBEARGS=(--context="$KCONTEXT")
  if [ -n "$KCONFIG" ]; then
    HELMARGS+=(--kubeconfig="$KCONFIG")
	KUBEARGS+=(--kubeconfig="$KCONFIG")
  fi

  # apply CRD during upgrade
  kubectl apply -f https://raw.githubusercontent.com/sparebankenvest/azure-key-vault-to-kubernetes/master/crds/AzureKeyVaultSecret.yaml "${KUBEARGS[@]}"

  helm upgrade akv2k8s spv-charts/akv2k8s --version 2.0.7 "${HELMARGS[@]}" \
    --install \
    --namespace devops \
    --set controller.nodeSelector."kubernetes\.io/os"=linux \
	--set-string controller.podLabels."sidecar\.istio\.io/inject"="false" \
    --set global.logFormat=json \
    --set global.logLevel=trace \
    --set env_injector.enabled=false \
    --atomic
}

set_kv_permissions() {

  local AKSRG=
  local SPID=

  color 42 "KeyVault Permissions"

  if IFS=$'\t' read -r group spid; then
    AKSRG=$group
    SPID=$spid
  fi < <(az aks list --query "[?name=='$CLUSTER'].{group:resourceGroup,spid:servicePrincipalProfile.clientId}" -o json 2>/dev/null | jq -rc '.[0] | [.group,.spid] | @tsv')

  if [ "$?" -ne 0 ] || [ -z "$AKSRG" ] || [ -z "$SPID" ]; then
    die 5 "Unable to retrieve Resource Group and Service Principal for $CLUSTER"
  fi

  local SPNAME="$SPID"

  # get the Service Principal's Display Name for friendly logging messages
  # also grab the objectId (--object-id) which we will use instead of clientId (--spn) when setting the perms
  local info=($(az ad sp show --id "$SPID" --query "[objectId,appDisplayName]"  -o json | jq -rc '.[0],.[1]'))
  if [ "$?" -ne 0 ] || [ ${#info[@]} -lt 2 ] || [ "${info[0]}" == "null" ] || [ -z "${info[0]}" ]; then
    die 6 "Could not retrieve Service Principal information for Id #$SPID"
  fi

  SPID="${info[0]}"
  if [ -n "${info[1]}" ]; then
    SPNAME="${info[1]}"
  fi

  echo "Setting Certificates Get/List Perms for Service Principal $SPNAME on $KEYVAULT"

  az keyvault set-policy --name "$KEYVAULT" --object-id "$SPID" --certificate-permissions get list --secret-permissions get list >/dev/null 2>&1

  ## alternatively, don't look up the object id for the SP and pass as --spn
  ##az keyvault set-policy --name "$KEYVAULT" --spn "$SPID" --certificate-permissions get list >/dev/null 2>&

  if [ "$?" -ne 0 ]; then
    die 7 "Failed to set Certificate Permissions for $SPNAME"
  fi

  color 32 "Access Policy applied successfully"

}

needs_arg() { if [ -z "$OPTARG" ]; then die "An argument is required for $ORIGARG" "$USAGE"; fi; }

KCONTEXT=
KCONFIG=
CLUSTER=
KEYVAULT=
DEPLOY_TO_VAULT=0
UNINSTNS=
DELETENS=0

while getopts ":u:Ux:k:pv:c:h-:" OPT
do
  ORIGARG="-$OPT"
  if [ "$OPT" = "-" ]; then
    OPT="${OPTARG%%=*}"
    OPTARG="${OPTARG#$OPT}"
    OPTARG="${OPTARG#=}"
    ORIGARG="--$OPT"
  fi
  case "$OPT" in
    x | context )         needs_arg; KCONTEXT=$OPTARG  ;;
    k | kubeconfig )      needs_arg; KCONFIG=$OPTARG   ;;
    p | set-vault-perms )            DEPLOY_TO_VAULT=1 ;;
    v | vault )           needs_arg; KEYVAULT=$OPTARG  ;;
    c | cluster )         needs_arg; CLUSTER=$OPTARG   ;;
    h | help )            echo "$USAGE"; exit 0        ;;
	u | uninstall )       needs_arg; UNINSTNS=$OPTARG  ;;
	U )                              DELETENS=1        ;;
    ??* )                 die "--${OPT} is not a valid option"   "$USAGE" ;;
    : )                   die "-${OPTARG} requires an argument"  "$USAGE" ;;
    * )                   die "-${OPTARG} is not a valid option" "$USAGE" ;;
  esac
done

shift $((OPTIND-1))

if [ $DEPLOY_TO_VAULT -eq 1 ] && ( [ -z "$KEYVAULT" ] || [ -z "$CLUSTER" ] ); then
  die 2 "cluster and vault names are required with --set-vault-perms flag"
fi

if [ -n "$UNINSTNS" ]; then
	uninstall_akv2k8s "$UNINSTNS" "$DELETENS"
fi
create_devops_namespace
install_akv2k8s

if [ "$DEPLOY_TO_VAULT" -eq 1 ]; then
  set_kv_permissions
fi

echo
color 32 "Script Complete"