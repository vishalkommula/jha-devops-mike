
install_flagger(){
    echo "adding flagger helm repo"
    helm repo add flagger https://flagger.app --insecure-skip-tls-verify
    helm repo update

    # MUST use this customized CRD in k8s 1.18+
    echo "installing flagger CRDs"
    kubectl apply -f ./flagger-crd.yaml

    echo "Installing flagger"
    helm upgrade -i flagger flagger/flagger --namespace=istio-system --set crd.create=false --set meshProvider=istio --set metricsServer=http://prometheus:9090 --set nodeSelector."kubernetes\.io/os"=linux --set msteams.url=https://jackhenry.webhook.office.com/webhookb2/a57b6351-eb40-4d4c-9683-559df619bfe2@53049b77-3e8f-4792-977f-0a3e5f23891b/IncomingWebhook/3699c1db72ec423690ad3ef22289c846/bde34a07-e727-4a1f-b67a-d5d24669c637 --insecure-skip-tls-verify
    echo "Installing loadtester"
    kubectl create ns flagger
    kubectl label ns flagger istio-injection=enabled
    helm upgrade -i flagger-loadtester flagger/loadtester --namespace=flagger --set cmd.timeout=1h --set nodeSelector."kubernetes\.io/os"=linux --insecure-skip-tls-verify
    kubectl apply -f ./flagger-disable-mtls.yaml
}

uninstall_flagger(){
    helm delete flagger --namespace istio-system
    kubectl delete --ignore-not-found=true crd canaries.flagger.app
    helm delete flagger-loadtester --namespace flagger
    kubectl delete --ignore-not-found=true -f ./flagger-disable-mtls.yaml
    kubectl delete --ignore-not-found=true namespace flagger
}

uninstall_flagger
install_flagger
