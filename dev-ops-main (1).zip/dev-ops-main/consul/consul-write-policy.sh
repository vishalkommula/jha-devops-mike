#!/bin/bash
CONSUL_ADDR=$1
CONSUL_TOKEN=$2

curl  \
    --request PUT \
    --header "X-Consul-Token: $CONSUL_TOKEN " \
    --data \
'{
  "Name": "newkey-write-policy",
  "Description": "Policy for generating tokens with write access to keys",
  "Rules": "key_prefix \"\" { policy = \"write\" }"
}' $CONSUL_ADDR/v1/acl/policy 


curl  \
  --request PUT \
  --header "X-Consul-Token: $CONSUL_TOKEN" \
  --data \
'{
  "Description": "Policy for generating tokens with write access to keys",
  "Policies": [
    {
      "Name": "newkey-write-policy"
    }
   ]	
}' $CONSUL_ADDR/v1/acl/token
