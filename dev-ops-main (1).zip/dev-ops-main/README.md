# Dev-Ops

  This repo contains various resources to install the infrastructure we will use in our cloud environment.

## consul

* This is a customized version of the official Consul helm chart. It has been modified to only install the necessary items for Consul KV which we will use to store application configuration. It is also includes the necessary resources to utilize Istio.
* This was initally installed with the following command.
  
  ```console
  helm install consul ./consul/. --create-namespace --namespace consul
  ```

  --https://www.consul.io/docs/dynamic-app-config/kv

## git2consul-docker

* git2consul is normally installed through npm. A Dockerfile has been created to wrap that application inside a container and also allows us to include a public/private key set that is linked to the JHA Banking Development GitHub consul-config repo to allow SSH access.

  ```console
  docker build -t devjhbankingcontainerregistry1.azurecr.io/git2consul .
  docker image push devjhbankingcontainerregistry1.azurecr.io/git2consul:latest
  ```

## git2consul

* This is a customized version of the git2consul helm chart which utilizes an image of git2consul store in our container registry. It has been modified to run in Kubernetes as a CronJob which allows it to run a copy of the application once per minute. The default values.yaml will synchronize with the consul-config repo at the config/DEV path.

  ```console
  helm install git2consul . --namespace consul
  ```

  --https://github.com/breser/git2consul

## pipeline-templates

* [ci/utility-service.yaml](pipeline-templates/ci/utility-service.yml)
  * This serves as a generic template for creating and pushing backend container images and helm charts to the Azure Container Registry. [Example](https://github.com/JHABankingDevelopment/configuration-proxy-service/blob/main/devops/scripts/configuration-proxy-service-ci-pipeline.yml)
* [pr/backend-pr-pipeline-template.yaml](pipeline-templates/pr/backend-pr-pipeline-template.yml)
  * This serves as a generic template for running a build and any unit tests to be used as a check for pull requests. [Example](https://github.com/JHABankingDevelopment/configuration-proxy-service/blob/main/devops/scripts/configuration-proxy-service-pr-pipeline.yaml)

## release-script/canary-monitor

* These scripts are used in the release pipelines to work with Flagger which is installed in the kubernetes cluster to perform a Canary release. When a new deployment is attempted it will have traffic progressively shifted to it while being tested for connectivity and errors. The setup script for Flagger includes a parameter to assign a webhook to a MS Teams channel is order to receive updates on this process which usually take around 5 minutes once the helm chart is deployed.

## setup-akv2k8s

* Azure Key Vault to Kubernetes (akv2k8s) is a utility that allows you to utilize a custom resource in Kubernetes to synchronize secrets, certificates, and keys so they can be used in Kubernetes.
  * [setup-akv2k8s.sh](SetupUIDEnvironment/setup-akv2k8s/setup-akv2k8s.sh)
    * This script will uninstall any old versions and install the latest build.

      ```console
      ./setup-akv2k8s.sh --context=dev-jhbanking-aks-cluster --vault=dev-jhbanking-kv2 --cluster=dev-jhbanking-aks-cluster
      ```

  * [domain-secret-sync.yaml](SetupUIDEnvironment/setup-akv2k8s/domain-secret-sync.yaml)
    * Normally each helm chart that needs to create a gateway to a public endpoint would have its own certificate. In our case we were provided with one certificate for the domain and all subdomains. This manifest creates the custom resource to synchronize the certificate from the Vault. The  Kubernetes secret 'dev-certificate' can be used in any chart needing that certificate.
  
      ```console
      kubectl apply -f domain-secret-sync.yaml
      ```
      
  --https://akv2k8s.io/

## setup-flagger

* This script will install Flagger which is a Progressive Delivery Operator for Kubernetes. This allow us to automate a canary release for our deployments along with notifications of progress to MS Teams.
  
  ```console
  ./setup-flagger.sh
  ```

## setup-istio

* This script will install/update Istio which is a service mesh providing observability, traffic management, security, and policy. The install takes a revision number as a parameter which should be the version of Istio that is being installed. This type of installation allows for an in place upgrade for future releases that will have minimal disruption to the environment.

  ```console
  ./install-upgrade-istio.sh 1.13.2
  ```

  --https://istio.io/